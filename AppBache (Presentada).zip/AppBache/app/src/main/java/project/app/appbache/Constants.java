package project.app.appbache;

import android.annotation.SuppressLint;

public class Constants {
    //Server Configuration
    public static final int SOCKET_TIMEOUT = 500000;
    public static final String PROTOCOL = "http://";
    public static final String ROOT_URL = PROTOCOL + "10.10.179.95";

    //PHP Scripts URL's
    public static final String URL_REGISTRO = ROOT_URL+"/Registro.php";
    public static final String URL_LOGIN = ROOT_URL+"/Login.php";
    public static final String URL_GET_REPORTS = ROOT_URL+"/GetReports.php";
    public static final String URL_REPORTE = ROOT_URL+"/Reportar.php";

    //Acciones
    public static final int PICK_IMAGE_REQUEST = 1;

    //Date Formate
    @SuppressLint("SimpleDateFormat")
    public static final String DateFormat = "yyyy-MM-dd hh:mm:ss a";

    //public static final int MY_DEFAULT_TIMEOUT = 500000;
}
