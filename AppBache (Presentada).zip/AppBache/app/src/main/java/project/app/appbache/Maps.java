package project.app.appbache;

import androidx.fragment.app.FragmentActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import android.widget.Toast;

import org.json.JSONArray;

import java.util.ArrayList;

public class Maps extends FragmentActivity implements OnMapReadyCallback, View.OnClickListener {

    Button Report;

    private GoogleMap mMap;


    ArrayList<Double> Latitud = new ArrayList<Double>();
    ArrayList<Double> Longitud = new ArrayList<Double>();
    ArrayList<Integer> Estatus = new ArrayList<Integer>();
    ArrayList<String> User = new ArrayList<>();
    private int Total_Reportes;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        Report = (Button) findViewById(R.id.bt_report);
        Report.setOnClickListener(this);

    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        mMap.setMinZoomPreference(12);
        mMap.moveCamera( CameraUpdateFactory.newLatLngZoom( new LatLng(29.0791144, -110.9842475), 12) );

        ReadMarkers();
        //for ( int i = 0 ; i<Total_Reportes ; i++ ){
        //    LatLng Reportes = new LatLng(Latitud.get(i), Longitud.get(i));
        //    mMap.addMarker(new MarkerOptions().
        //            position(Reportes)
        //    );
        //}

        new CountDownTimer(30000, 1000) {

            public void onTick(long millisUntilFinished) {
                ReadMarkers();

                for ( int i = 0 ; i<Total_Reportes ; i++ ){
                    LatLng Reportes = new LatLng(Latitud.get(i), Longitud.get(i));
                    mMap.addMarker(new MarkerOptions().position(Reportes));
                }
            }

            public void onFinish() {
                //mTextField.setText("done!");
            }
        }.start();

    }

    public void ReadMarkers() {
        StringRequest stringRequest = new StringRequest(
                Request.Method.POST,
                Constants.URL_GET_REPORTS,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        //progressDialog.dismiss();

                        //

                        try {

                            JSONArray obj = new JSONArray(response);
                           // JsonObject obj = new JsonParser().parse(response).getAsJsonObject();
                            JSONArray JSONUser = obj.getJSONArray(0);
                            JSONArray JSONLatitud = obj.getJSONArray(1);
                            JSONArray JSONLongitud = obj.getJSONArray(2);
                            JSONArray JSONEstatus = obj.getJSONArray(3);

                            for ( int i = 0 ; i<JSONLatitud.length() ; i++ ){
                                Latitud.add(JSONLatitud.getDouble(i));
                            }

                            for ( int i = 0 ; i<JSONLatitud.length() ; i++ ){
                                Longitud.add(JSONLongitud.getDouble(i));
                            }

                            for ( int i = 0 ; i<JSONLatitud.length() ; i++ ){
                                Estatus.add(JSONEstatus.getInt(i));
                            }

                            for ( int i = 0 ; i<JSONUser.length() ; i++ ){
                                User.add(JSONUser.getString(i));
                            }


                            Total_Reportes = Latitud.size();


                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(
                                getApplicationContext(),
                                error.getMessage(),
                                Toast.LENGTH_LONG
                        );
                    }
                }
        );

        RetryPolicy policy = new DefaultRetryPolicy(Constants.SOCKET_TIMEOUT,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);

        stringRequest.setRetryPolicy(policy);
        RequestHandler.getInstance(this).addToRequestQueue(stringRequest);
    }

    @Override
    public void onClick(View v) {
        Intent i = new Intent(getApplicationContext(), Reporte.class);
        startActivity(i);
    }

    @Override
    public void onBackPressed(){

    }
}
