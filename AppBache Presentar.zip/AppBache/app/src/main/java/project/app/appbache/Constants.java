package project.app.appbache;

import android.annotation.SuppressLint;

import java.text.SimpleDateFormat;
import java.util.Locale;

public class Constants {
    //Server Configuration
    public static final int SOCKET_TIMEOUT = 500000;
    public static final String PROTOCOL = "http://";
    public static final String ROOT_URL = PROTOCOL + "10.10.147.201";

    //PHP Scripts URL's
    public static final String URL_REGISTRO = ROOT_URL+"/Registro.php";
    public static final String URL_LOGIN = ROOT_URL+"/Login.php";
    public static final String URL_GET_REPORTS = ROOT_URL+"/GetReports.php";
    public static final String URL_REPORTE = ROOT_URL+"/Reportar.php";

    //Acciones
    static final int REQUEST_IMAGE_CAPTURE = 1;

    //Date Formate
    @SuppressLint("SimpleDateFormat")
    public static final String DateFormat = "yyyy-MM-dd hh:mm:ss a";

    //public static final int MY_DEFAULT_TIMEOUT = 500000;
}
