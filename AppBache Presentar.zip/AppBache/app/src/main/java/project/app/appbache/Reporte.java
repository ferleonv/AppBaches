package project.app.appbache;

import android.Manifest;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.content.FileProvider;
import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class Reporte extends Activity implements View.OnClickListener, LocationListener {
    Button Reportar, UploadImagen;
    ProgressDialog Dialog;
    ImageView imageView;


    double Latitud, Longitud;
    String currentTime;
    TextView Correo;
    Date date;


    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.reporte_activity);

        Reportar = findViewById(R.id.b_Subir);
        UploadImagen = findViewById(R.id.b_Imagen);
        Correo = findViewById(R.id.tv_User);
        date = new Date();

        Reportar.setOnClickListener(this);
        UploadImagen.setOnClickListener(this);
        Correo.setText(SharedPrefManager.getInstance(this).getCorreo());

        Dialog = new ProgressDialog(this);


    }

    private void makeReport(){
        //final String Password = PT_Password.getText().toString().trim();
        currentTime = Constants.DateFormat.format(String.valueOf(date));

        Dialog.setMessage("Reportando...");
        Dialog.show();

        StringRequest StringRequest = new StringRequest(Request.Method.POST,
                Constants.URL_REPORTE,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Dialog.dismiss();

                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            Toast.makeText(getApplicationContext(), jsonObject.getString("message"), Toast.LENGTH_LONG).show();

                            //Intent i = new Intent(getApplicationContext(), Maps.class);
                            //startActivity(i);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Dialog.hide();
                        Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_LONG ).show();

                        Intent i = new Intent(getApplicationContext(), Maps.class);
                        startActivity(i);
                    }
                }
        ){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> Params = new HashMap<>();
                Params.put( "Latitud", Latitud+"" );
                Params.put( "Longitud", Longitud+"");
                Params.put( "User", /*Correo.getText().toString()*/"lferht@gmail.com" );
                Params.put( "Fecha", currentDate() );
                //Params.put( "Image_Path", imageFilePath );

                return Params;

            }
        };

        RequestHandler.getInstance(this).addToRequestQueue(StringRequest);

    }


    @Override
    public void onClick(View v) {
        if (v == Reportar) {


            makeReport();
        } else if (v == UploadImagen) {
            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            startActivityForResult(intent,0);
        }
    }

    @Override
    public void onLocationChanged(Location location) {

    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    @Override
    public void onProviderDisabled(String provider) {

    }

    public static String currentDate() {
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

        Date date = new Date();

        return dateFormat.format(date);
    }

    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Bitmap bitmap = (Bitmap)data.getExtras().get("data");

        imageView.setImageBitmap(bitmap);
    }
}
